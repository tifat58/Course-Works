Name: Sharara Ferdous
Matriculation Number: 2571657
Email: s8shferd@stud.uni-saarland.de

Name: Hasan Md Tusfiqur Alam
Matriculation Number: 2571663
Email: s8haalam@stud.uni-saarland.de